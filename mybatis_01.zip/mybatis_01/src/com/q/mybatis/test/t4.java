package com.q.mybatis.test;

import com.q.mybatis.dao.UserDao;
import com.q.mybatis.dao.UserDaoImpl;
import com.q.mybatis.mapper.UserMapper;
import com.q.mybatis.model.User;
import com.q.mybatis.vo.UserQueryVO;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

public class t4 {

    SqlSession session;

    @Before
    public void before() throws IOException {

        System.out.println("insert Before");

        // 1. 读取配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");

        // 2. 通过 SqlSessionFactoryBuilder 创建 SqlSessionFactory 会话工厂
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(is);


        session = sessionFactory.openSession();
    }


    @After
    public void after(){
        session.close();
    }


    @Test
    public void test1(){
        UserMapper userMapper = session.getMapper(UserMapper.class);

        // 获取数据
        System.out.println(userMapper.getUserById(1));

        // 添加数据
//        User user1 = new User("t4_5","1",new Date(), "addr");
//        userMapper.save(user1);
        session.commit();
    }


    @Test
    public void test2(){
        UserMapper userMapper = session.getMapper(UserMapper.class);
        UserQueryVO query = new UserQueryVO();

        User user = new User();
        user.setSex("1");

        query.setUser(user);

        List<User> users = userMapper.findUserList(query);
        System.out.println(users);
    }


}





















