package com.q.mybatis.test;

import com.q.mybatis.model.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class t2 {

    SqlSession session;

    @Before
    public void before() throws IOException {

        System.out.println("insert Before");

        // 1. 读取配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");

        // 2. 通过 SqlSessionFactoryBuilder 创建 SqlSessionFactory 会话工厂
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(is);

        // 3. 通过 SqlSessionFactory 创建 SqlSession
        session = sessionFactory.openSession();
    }

    @After
    public void after(){
        System.out.println("insert After");
        // 5. 关闭 Session
        session.close();
    }



    // 插入数据
    @Test
    public void demo1() {
        User user = new User("q2", "1", new Date(), "shanghai");
        session.insert("insertUser", user);
        session.commit();
    }


    // 删除数据
    @Test
    public void demo2() {
        session.delete("deleteUser", 1);
        session.commit();
    }

    // 更新数据
    @Test
    public void demo3() {
        User user = new User();
        user.setId(15);
        user.setUsername("test1");
        int affectRow = session.update("updateUser",user);
        session.commit();
        System.out.println("line:  " +affectRow);
    }


    // 插入数据 时返回 数据 id
    @Test
    public void demo4() {
        User user = new User("e5", "1", new Date(), "shanghai");
        session.insert("insertUser1", user);
        session.commit();
        System.out.println("id ："+user.getId());
    }

}





















