package com.q.mybatis.test;

import com.q.mybatis.model.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

public class t1 {

    // 查询数据
    @Test
    public void test1() throws IOException {
        // 1. 读取配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");

        // 2. 通过 SqlSessionFactoryBuilder 创建 SqlSessionFactory 会话工厂
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(is);

        // 3. 通过 SqlSessionFactory 创建 SqlSession
        SqlSession session = sessionFactory.openSession();

        // 4. 通过 SqlSession 操作数据库
        User user = session.selectOne("findUserById",1);
        System.out.println(user);

        // 5. 关闭 Session
        session.close();

    }

}





















