package com.q.mybatis.test;

import com.q.mybatis.dao.UserDao;
import com.q.mybatis.dao.UserDaoImpl;
import com.q.mybatis.model.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class t3 {

    SqlSessionFactory sessionFactory;

    @Before
    public void before() throws IOException {

        System.out.println("insert Before");

        // 1. 读取配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");

        // 2. 通过 SqlSessionFactoryBuilder 创建 SqlSessionFactory 会话工厂
        sessionFactory = new SqlSessionFactoryBuilder().build(is);
    }


    // 查询一条数据
    @Test
    public void demo1() {
        UserDao userDao = new UserDaoImpl(sessionFactory);
        User user1 = userDao.findUserById(1);
        System.out.println(user1);
    }

    // 插入一条数据
    @Test
    public void demo2() {
        UserDao userDao = new UserDaoImpl(sessionFactory);
        User user = new User("qwe","1",new Date(),  "address1");
        userDao.save(user);
    }


}





















