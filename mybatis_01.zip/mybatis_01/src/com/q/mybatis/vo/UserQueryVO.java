package com.q.mybatis.vo;

import com.q.mybatis.model.User;

public class UserQueryVO {

    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
