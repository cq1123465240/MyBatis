package com.q.mybatis.mapper;

import com.q.mybatis.model.User;
import com.q.mybatis.vo.UserQueryVO;

import java.util.List;

public interface UserMapper {

    public int save(User user);

    public User getUserById(int id);

    List<User> findUserList(UserQueryVO vo);
}
