package com.q.mybatis.dao;

import com.q.mybatis.model.User;

public interface UserDao {

    public void save(User user);

    public User findUserById(int id);

}
