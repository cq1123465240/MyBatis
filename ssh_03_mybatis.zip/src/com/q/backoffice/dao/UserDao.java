package com.q.backoffice.dao;

import com.q.backoffice.model.User;

public interface UserDao {

    User findUserById(int id);

}
