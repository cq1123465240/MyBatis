package com.q.backoffice.mapper;

import com.q.backoffice.model.User;

public interface UserMapper {

    User findUserById(int id);

}
