import com.q.backoffice.mapper.UserMapper;
import com.q.backoffice.model.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

    @Test
    public void test1(){
        // 1.加载 sSpring 配置文件
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // 2. 获取 Dao 的 Bean
        UserMapper userMapper = (UserMapper) context.getBean("userMapper");

        // 3. 调用 Dao 方法
        User user = userMapper.findUserById(1);
        System.out.println(user);
    }

}
